// FunHub Stage A — engagement features run locally in the visitor's browser.
document.addEventListener("DOMContentLoaded", () => {
  const menuBtn = document.querySelector(".menu-btn");
  const nav = document.querySelector(".nav");
  if (menuBtn && nav) menuBtn.addEventListener("click", () => nav.classList.toggle("open"));

  const STORAGE = {
    reaction: "funhub_best_reaction",
    guess: "funhub_best_guess",
    memory: "funhub_best_memory",
    daily: "funhub_daily_completed"
  };

  const todayKey = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };

  const dailyChallenges = [
    { type:"reaction", title:"Beat 350 ms", description:"Test your reflexes and finish with a reaction time under 350 ms.", target:"Goal: under 350 ms", anchor:"reaction" },
    { type:"guess", title:"Crack the number", description:"Find today's hidden number in 7 guesses or fewer.", target:"Goal: 7 guesses or fewer", anchor:"guess" },
    { type:"memory", title:"Reach Memory Level 5", description:"Keep the sequence in your head and reach level 5.", target:"Goal: reach level 5", anchor:"memory" }
  ];

  const daily = dailyChallenges[(Math.floor(Date.now() / 86400000)) % dailyChallenges.length];
  const dailyCompleted = () => localStorage.getItem(STORAGE.daily) === todayKey() + ":" + daily.type;
  const completeDaily = (type) => {
    if (type === daily.type) localStorage.setItem(STORAGE.daily, todayKey() + ":" + type);
    updateDailyUI();
  };
  const updateDailyUI = () => {
    const done = dailyCompleted();
    const homeTitle = document.querySelector("#daily-title");
    const homeDesc = document.querySelector("#daily-description");
    const homeTarget = document.querySelector("#daily-target");
    const homeStatus = document.querySelector("#daily-status");
    const homeLink = document.querySelector("#daily-link");
    const badge = document.querySelector("#daily-badge");
    if (homeTitle) homeTitle.textContent = daily.title;
    if (homeDesc) homeDesc.textContent = daily.description;
    if (homeTarget) homeTarget.textContent = daily.target;
    if (homeStatus) homeStatus.textContent = done ? "✓ Completed today" : "Not completed yet";
    if (homeStatus) homeStatus.classList.toggle("complete", done);
    if (homeLink) homeLink.href = `./games.html#${daily.anchor}`;
    if (badge) badge.textContent = String(new Date().getDate()).padStart(2,"0");

    const gameTitle = document.querySelector("#games-daily-title");
    const gameDesc = document.querySelector("#games-daily-description");
    const gameTarget = document.querySelector("#games-daily-target");
    const gameStatus = document.querySelector("#games-daily-status");
    if (gameTitle) gameTitle.textContent = daily.title;
    if (gameDesc) gameDesc.textContent = daily.description;
    if (gameTarget) gameTarget.textContent = daily.target;
    if (gameStatus) {
      gameStatus.textContent = done ? "✓ Completed today" : "Not completed";
      gameStatus.classList.toggle("complete", done);
    }
  };
  updateDailyUI();

  const setBest = (key, value) => localStorage.setItem(key, String(value));
  const getBest = (key) => localStorage.getItem(key);
  const updateBestText = (id, value, formatter) => {
    const el = document.querySelector(id);
    if (el) el.textContent = value == null ? "—" : formatter(value);
  };

  // Reaction Test
  const rBox = document.querySelector("#reaction-box");
  const rBtn = document.querySelector("#reaction-btn");
  const rResult = document.querySelector("#reaction-result");
  let rTimer = null, rStart = 0, rActive = false;
  const startReaction = () => {
    if (!rBox || !rBtn) return;
    clearTimeout(rTimer);
    rActive = false;
    rBox.className = "reaction-box wait";
    rBox.textContent = "Wait for green...";
    rResult.textContent = "";
    rBtn.textContent = "Wait...";
    rTimer = setTimeout(() => {
      rActive = true;
      rStart = performance.now();
      rBox.className = "reaction-box go";
      rBox.textContent = "CLICK!";
      rBtn.textContent = "Click the box!";
    }, 900 + Math.random() * 2500);
  };
  const finishReaction = () => {
    const ms = Math.round(performance.now() - rStart);
    rActive = false;
    rBox.className = "reaction-box ready";
    rBox.textContent = "Nice!";
    rResult.textContent = `${ms} ms reaction time`;
    rBtn.textContent = "Try again";
    const old = Number(getBest(STORAGE.reaction));
    if (!old || ms < old) {
      setBest(STORAGE.reaction, ms);
      rResult.textContent += " • New personal best! 🏆";
    }
    updateBestText("#reaction-best", getBest(STORAGE.reaction), v => `${v} ms`);
    if (daily.type === "reaction" && ms < 350) completeDaily("reaction");
  };
  if (rBox && rBtn) {
    rBox.addEventListener("click", () => {
      if (rActive) finishReaction();
      else if (rBox.classList.contains("wait")) {
        clearTimeout(rTimer); rActive = false;
        rBox.className = "reaction-box ready"; rBox.textContent = "Too early!";
        rResult.textContent = "Wait until the screen turns green.";
        rBtn.textContent = "Start again";
      }
    });
    rBtn.addEventListener("click", () => {
      if (rActive) finishReaction();
      else if (rBox.classList.contains("wait")) {
        clearTimeout(rTimer); rActive = false;
        rBox.className = "reaction-box ready"; rBox.textContent = "Too early!";
        rResult.textContent = "Too early — wait for green.";
        rBtn.textContent = "Start again";
      } else startReaction();
    });
  }
  updateBestText("#reaction-best", getBest(STORAGE.reaction), v => `${v} ms`);

  // Number guessing
  const gInput = document.querySelector("#guess-input");
  const gBtn = document.querySelector("#guess-btn");
  const gResult = document.querySelector("#guess-result");
  const gReset = document.querySelector("#guess-reset");
  let target = Math.floor(Math.random()*100)+1, attempts = 0, solved = false;
  const resetGuess = () => {
    target = Math.floor(Math.random()*100)+1;
    attempts = 0; solved = false;
    if (gInput) { gInput.value=""; gInput.focus(); }
    if (gResult) gResult.textContent="New number ready.";
    if (gBtn) gBtn.disabled = false;
  };
  const makeGuess = () => {
    if (!gInput || !gResult || solved) return;
    const n = Number(gInput.value);
    if (!Number.isInteger(n) || n < 1 || n > 100) { gResult.textContent="Enter a whole number from 1 to 100."; return; }
    attempts++;
    if (n === target) {
      solved = true;
      const old = Number(getBest(STORAGE.guess));
      if (!old || attempts < old) setBest(STORAGE.guess, attempts);
      gResult.textContent = `Correct! You got it in ${attempts} ${attempts===1?"guess":"guesses"}. 🎉${(!old || attempts < old) ? " New personal best! 🏆" : ""}`;
      updateBestText("#guess-best", getBest(STORAGE.guess), v => `${v} ${Number(v)===1?"guess":"guesses"}`);
      if (daily.type === "guess" && attempts <= 7) completeDaily("guess");
    } else {
      gResult.textContent = n < target ? "Too low — try again." : "Too high — try again.";
    }
  };
  if (gBtn) gBtn.addEventListener("click", makeGuess);
  if (gInput) gInput.addEventListener("keydown", e => { if (e.key === "Enter") makeGuess(); });
  if (gReset) gReset.addEventListener("click", resetGuess);
  updateBestText("#guess-best", getBest(STORAGE.guess), v => `${v} ${Number(v)===1?"guess":"guesses"}`);

  // Memory Challenge
  const mDisplay=document.querySelector("#memory-sequence"), mBtn=document.querySelector("#memory-btn"), mInput=document.querySelector("#memory-input"), mResult=document.querySelector("#memory-result");
  let memoryLevel=0, memorySequence="", memoryChecking=false;
  const startMemoryRound = () => {
    if (!mDisplay || !mBtn || !mInput) return;
    memoryLevel++;
    memorySequence="";
    for(let i=0;i<memoryLevel+2;i++) memorySequence += Math.floor(Math.random()*10);
    memoryChecking=false;
    mDisplay.textContent=memorySequence;
    mInput.value=""; mInput.classList.add("hidden");
    mResult.textContent="";
    mBtn.disabled=true; mBtn.textContent="Memorize...";
    setTimeout(()=>{
      memoryChecking=true;
      mDisplay.textContent="???";
      mInput.classList.remove("hidden");
      mInput.focus();
      mBtn.disabled=false; mBtn.textContent="Check";
    }, Math.max(1200,1500+memoryLevel*250));
  };
  const checkMemory = () => {
    if (!memoryChecking || !mInput) return;
    memoryChecking=false;
    const correct=mInput.value.trim()===memorySequence;
    if(correct){
      const old=Number(getBest(STORAGE.memory)||0);
      if(memoryLevel>old) setBest(STORAGE.memory,memoryLevel);
      mResult.textContent=`Correct! Level ${memoryLevel} complete. 🧠${memoryLevel>old ? " New personal best! 🏆" : ""}`;
      if(daily.type === "memory" && memoryLevel >= 5) completeDaily("memory");
      mDisplay.textContent="Ready for the next level?";
      mInput.classList.add("hidden");
      mBtn.textContent="Next level";
    } else {
      mResult.textContent=`Not quite. The sequence was ${memorySequence}.`;
      memoryLevel=0;
      mInput.classList.add("hidden");
      mDisplay.textContent="Try again?";
      mBtn.textContent="Start again";
    }
    updateBestText("#memory-best", getBest(STORAGE.memory)||0, v => `Level ${v}`);
  };
  if(mBtn) mBtn.addEventListener("click", () => memoryChecking ? checkMemory() : startMemoryRound());
  if(mInput) mInput.addEventListener("keydown", e => { if (e.key === "Enter") checkMemory(); });
  updateBestText("#memory-best", getBest(STORAGE.memory)||0, v => `Level ${v}`);

  // Quick replay buttons
  document.querySelectorAll("[data-replay]").forEach(btn => btn.addEventListener("click", () => {
    const type=btn.dataset.replay;
    if(type==="reaction") startReaction();
    if(type==="memory") { memoryLevel=0; memoryChecking=false; if(mDisplay) mDisplay.textContent="Ready?"; if(mResult) mResult.textContent=""; if(mInput) mInput.classList.add("hidden"); if(mBtn) mBtn.textContent="Start challenge"; }
  }));

  // If the user lands on a game anchor from the Daily Challenge, highlight it briefly.
  if (location.hash && document.querySelector(location.hash)) {
    setTimeout(() => document.querySelector(location.hash)?.scrollIntoView({behavior:"smooth", block:"center"}), 120);
  }

  const copyItem = (text) => navigator.clipboard?.writeText(text);
  const makeItems = (el, items) => {
    if (!el) return;
    el.innerHTML="";
    items.forEach(item=>{
      const row=document.createElement("div"); row.className="output-item";
      row.innerHTML=`<span>${item}</span><button class="copy-btn" type="button">Copy</button>`;
      row.querySelector("button").addEventListener("click",()=>copyItem(item));
      el.appendChild(row);
    });
  };

  // Username generator
  const uBtn=document.querySelector("#username-btn"), uOut=document.querySelector("#username-output"), uVibe=document.querySelector("#username-vibe");
  if(uBtn) uBtn.addEventListener("click",()=>{
    const first=["Nova","Shadow","Pixel","Lunar","Echo","Vortex","Frost","Neon","Orbit","Rogue","Zen","Drift"];
    const second={cool:["X","Wave","Mode","Rush","Core"],gaming:["GG","Quest","Boss","Byte","XP"],minimal:["One","Zero","Line","Void","Mono"],fun:["Noodle","Bubbles","Pickle","Mango","Waffles"]}[uVibe.value];
    const arr=[...Array(8)].map(()=>first[Math.floor(Math.random()*first.length)]+second[Math.floor(Math.random()*second.length)]+(Math.random()<.5?"":Math.floor(Math.random()*99)));
    makeItems(uOut,[...new Set(arr)].slice(0,8));
  });

  // Nickname generator
  const nBtn=document.querySelector("#nickname-btn"), nOut=document.querySelector("#nickname-output"), nInput=document.querySelector("#nickname-input");
  if(nBtn) nBtn.addEventListener("click",()=>{
    const name=nInput.value.trim(); if(!name){nOut.innerHTML='<div class="output-item">Enter a name first.</div>';return;}
    const base=name.charAt(0).toUpperCase()+name.slice(1);
    const variants=[base+"y",base.slice(0,Math.min(4,base.length))+"o", "Lil "+base, base+"ster", base+"u", "Captain "+base, base+"zilla", "The "+base];
    makeItems(nOut,variants);
  });

  // Bio generator
  const bBtn=document.querySelector("#bio-btn"), bOut=document.querySelector("#bio-output"), bVibe=document.querySelector("#bio-vibe");
  const bios={
    chill:["Taking it easy, one day at a time.","Good vibes. Quiet mind. Big dreams.","Offline sometimes. Living always."],
    funny:["Professional overthinker. Part-time legend.","Powered by snacks and questionable decisions.","I came. I saw. I forgot why I came."],
    ambitious:["Building quietly. Letting results speak.","Small steps. Big vision.","Learning today. Building tomorrow."],
    mysterious:["You know my name, not my story.","Some things are better left unsaid.","Observe more. Explain less."]
  };
  if(bBtn) bBtn.addEventListener("click",()=>makeItems(bOut,bios[bVibe.value]));

  // Calculators
  const ageBtn=document.querySelector("#age-btn"), ageResult=document.querySelector("#age-result"), dob=document.querySelector("#dob");
  if(ageBtn) ageBtn.addEventListener("click",()=>{
    if(!dob.value){ageResult.textContent="Choose your date of birth.";return;}
    const birth=new Date(dob.value+"T00:00:00"), now=new Date();
    let years=now.getFullYear()-birth.getFullYear(), months=now.getMonth()-birth.getMonth(), days=now.getDate()-birth.getDate();
    if(days<0){months--; const prev=new Date(now.getFullYear(),now.getMonth(),0); days+=prev.getDate();}
    if(months<0){years--;months+=12;}
    ageResult.textContent=`You are ${years} years, ${months} months and ${days} days old.`;
  });
  const pBtn=document.querySelector("#percent-btn"), pRes=document.querySelector("#percent-result");
  if(pBtn) pBtn.addEventListener("click",()=>{
    const part=Number(document.querySelector("#percent-part").value), total=Number(document.querySelector("#percent-total").value);
    if(!total){pRes.textContent="Enter a non-zero total.";return;} pRes.textContent=`${((part/total)*100).toFixed(2)}%`;
  });
  const dBtn=document.querySelector("#date-btn"), dRes=document.querySelector("#date-result");
  if(dBtn) dBtn.addEventListener("click",()=>{
    const a=new Date(document.querySelector("#date-one").value), b=new Date(document.querySelector("#date-two").value);
    if(isNaN(a)||isNaN(b)){dRes.textContent="Choose both dates.";return;}
    dRes.textContent=`${Math.round(Math.abs(b-a)/86400000).toLocaleString()} days`;
  });
});
